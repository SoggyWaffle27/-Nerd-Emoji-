document.getElementById('redirectButton').addEventListener('click', function() {
    window.location.href = 'https://www.google.com';
});
