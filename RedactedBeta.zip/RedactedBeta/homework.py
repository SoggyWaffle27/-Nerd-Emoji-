def scramble(x):
    if len(x) == 1:
        return x
    return (scramble(x[0:-1]))

print(scramble("abc"))
print("abc"[0:-1])