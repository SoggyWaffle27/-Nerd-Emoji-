// Select all <p> tags on the page
const paragraphs = document.querySelectorAll("p");

function changeRandomWordInParagraph(paragraphElement) {
    // Get the text content of the paragraph element
    const paragraph = paragraphElement.textContent;

    // Split the paragraph into words
    const words = paragraph.split(" ");

    // If there are no words, return the original text
    if (words.length === 0) {
        return paragraph;
    }
    const replacementWords = ["REDACTED"];
    // Choose a random index
    const index = Math.floor(Math.random() * replacementWords.length);
    const times = Math.floor(Math.random() * 10);

    for (let i = 0; i < times; i++ ) {
        const randomIndex = Math.floor(Math.random() * words.length);
        words[randomIndex] = replacementWords[index];
    }
    // Join the words back into a string
    const modifiedParagraph = words.join(" ");

    // Update the paragraph element's content
    paragraphElement.textContent = modifiedParagraph;
}

// Example: Change a random word in every paragraph to "cat"
paragraphs.forEach(paragraphElement => {
    changeRandomWordInParagraph(paragraphElement);
});
